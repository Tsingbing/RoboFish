/****************************************************************************
** Meta object code from reading C++ file 'mainwindow.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.9.1)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../mainwindow.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'mainwindow.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.9.1. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
struct qt_meta_stringdata_MainWindow_t {
    QByteArrayData data[31];
    char stringdata0[303];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_MainWindow_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_MainWindow_t qt_meta_stringdata_MainWindow = {
    {
QT_MOC_LITERAL(0, 0, 10), // "MainWindow"
QT_MOC_LITERAL(1, 11, 7), // "initMap"
QT_MOC_LITERAL(2, 19, 0), // ""
QT_MOC_LITERAL(3, 20, 10), // "openDialog"
QT_MOC_LITERAL(4, 31, 23), // "on_switchButton_clicked"
QT_MOC_LITERAL(5, 55, 24), // "handleQJoystickAxisEvent"
QT_MOC_LITERAL(6, 80, 19), // "QJoystickAxisEvent*"
QT_MOC_LITERAL(7, 100, 5), // "event"
QT_MOC_LITERAL(8, 106, 26), // "handleQJoystickButtonEvent"
QT_MOC_LITERAL(9, 133, 21), // "QJoystickButtonEvent*"
QT_MOC_LITERAL(10, 155, 8), // "addPoint"
QT_MOC_LITERAL(11, 164, 2), // "id"
QT_MOC_LITERAL(12, 167, 4), // "type"
QT_MOC_LITERAL(13, 172, 3), // "lon"
QT_MOC_LITERAL(14, 176, 3), // "lat"
QT_MOC_LITERAL(15, 180, 9), // "pointType"
QT_MOC_LITERAL(16, 190, 4), // "size"
QT_MOC_LITERAL(17, 195, 5), // "color"
QT_MOC_LITERAL(18, 201, 8), // "addImage"
QT_MOC_LITERAL(19, 210, 5), // "layer"
QT_MOC_LITERAL(20, 216, 2), // "Id"
QT_MOC_LITERAL(21, 219, 4), // "path"
QT_MOC_LITERAL(22, 224, 5), // "width"
QT_MOC_LITERAL(23, 230, 6), // "height"
QT_MOC_LITERAL(24, 237, 5), // "angle"
QT_MOC_LITERAL(25, 243, 8), // "addLayer"
QT_MOC_LITERAL(26, 252, 10), // "clearRuler"
QT_MOC_LITERAL(27, 263, 10), // "startRuler"
QT_MOC_LITERAL(28, 274, 15), // "acceptFlashData"
QT_MOC_LITERAL(29, 290, 3), // "str"
QT_MOC_LITERAL(30, 294, 8) // "addLabel"

    },
    "MainWindow\0initMap\0\0openDialog\0"
    "on_switchButton_clicked\0"
    "handleQJoystickAxisEvent\0QJoystickAxisEvent*\0"
    "event\0handleQJoystickButtonEvent\0"
    "QJoystickButtonEvent*\0addPoint\0id\0"
    "type\0lon\0lat\0pointType\0size\0color\0"
    "addImage\0layer\0Id\0path\0width\0height\0"
    "angle\0addLayer\0clearRuler\0startRuler\0"
    "acceptFlashData\0str\0addLabel"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_MainWindow[] = {

 // content:
       7,       // revision
       0,       // classname
       0,    0, // classinfo
      12,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: name, argc, parameters, tag, flags
       1,    0,   74,    2, 0x0a /* Public */,
       3,    0,   75,    2, 0x0a /* Public */,
       4,    0,   76,    2, 0x0a /* Public */,
       5,    1,   77,    2, 0x0a /* Public */,
       8,    1,   80,    2, 0x0a /* Public */,
      10,    7,   83,    2, 0x0a /* Public */,
      18,    9,   98,    2, 0x0a /* Public */,
      25,    1,  117,    2, 0x0a /* Public */,
      26,    0,  120,    2, 0x0a /* Public */,
      27,    0,  121,    2, 0x0a /* Public */,
      28,    1,  122,    2, 0x0a /* Public */,
      30,    1,  125,    2, 0x0a /* Public */,

 // slots: parameters
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, 0x80000000 | 6,    7,
    QMetaType::Void, 0x80000000 | 9,    7,
    QMetaType::Void, QMetaType::UChar, QMetaType::QString, QMetaType::Float, QMetaType::Float, QMetaType::QString, QMetaType::Int, QMetaType::Int,   11,   12,   13,   14,   15,   16,   17,
    QMetaType::Void, QMetaType::QString, QMetaType::UChar, QMetaType::QString, QMetaType::QString, QMetaType::UChar, QMetaType::UChar, QMetaType::Float, QMetaType::Float, QMetaType::Int,   19,   20,   12,   21,   22,   23,   13,   14,   24,
    QMetaType::Void, QMetaType::QString,    2,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::QString,   29,
    QMetaType::Void, QMetaType::QString,    2,

       0        // eod
};

void MainWindow::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        MainWindow *_t = static_cast<MainWindow *>(_o);
        Q_UNUSED(_t)
        switch (_id) {
        case 0: _t->initMap(); break;
        case 1: _t->openDialog(); break;
        case 2: _t->on_switchButton_clicked(); break;
        case 3: _t->handleQJoystickAxisEvent((*reinterpret_cast< QJoystickAxisEvent*(*)>(_a[1]))); break;
        case 4: _t->handleQJoystickButtonEvent((*reinterpret_cast< QJoystickButtonEvent*(*)>(_a[1]))); break;
        case 5: _t->addPoint((*reinterpret_cast< quint8(*)>(_a[1])),(*reinterpret_cast< QString(*)>(_a[2])),(*reinterpret_cast< float(*)>(_a[3])),(*reinterpret_cast< float(*)>(_a[4])),(*reinterpret_cast< QString(*)>(_a[5])),(*reinterpret_cast< int(*)>(_a[6])),(*reinterpret_cast< int(*)>(_a[7]))); break;
        case 6: _t->addImage((*reinterpret_cast< QString(*)>(_a[1])),(*reinterpret_cast< quint8(*)>(_a[2])),(*reinterpret_cast< QString(*)>(_a[3])),(*reinterpret_cast< QString(*)>(_a[4])),(*reinterpret_cast< quint8(*)>(_a[5])),(*reinterpret_cast< quint8(*)>(_a[6])),(*reinterpret_cast< float(*)>(_a[7])),(*reinterpret_cast< float(*)>(_a[8])),(*reinterpret_cast< int(*)>(_a[9]))); break;
        case 7: _t->addLayer((*reinterpret_cast< QString(*)>(_a[1]))); break;
        case 8: _t->clearRuler(); break;
        case 9: _t->startRuler(); break;
        case 10: _t->acceptFlashData((*reinterpret_cast< QString(*)>(_a[1]))); break;
        case 11: _t->addLabel((*reinterpret_cast< QString(*)>(_a[1]))); break;
        default: ;
        }
    }
}

const QMetaObject MainWindow::staticMetaObject = {
    { &QMainWindow::staticMetaObject, qt_meta_stringdata_MainWindow.data,
      qt_meta_data_MainWindow,  qt_static_metacall, nullptr, nullptr}
};


const QMetaObject *MainWindow::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *MainWindow::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_MainWindow.stringdata0))
        return static_cast<void*>(const_cast< MainWindow*>(this));
    return QMainWindow::qt_metacast(_clname);
}

int MainWindow::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QMainWindow::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 12)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 12;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 12)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 12;
    }
    return _id;
}
QT_WARNING_POP
QT_END_MOC_NAMESPACE
